#!/bin/sh

${PANEL_LED} ${LED_LOGIN_MODE}
