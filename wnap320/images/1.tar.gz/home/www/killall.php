<?php
exec("/usr/local/bin/firmware-upgrade-web",$dummy, $res);
sleep(20);
?>

